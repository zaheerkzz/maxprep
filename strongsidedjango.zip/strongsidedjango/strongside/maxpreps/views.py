from rest_framework.response import Response
from rest_framework.views import APIView
from maxpreps.scrappers.maxpreps.players import Players

# Create your views here.


class MaxPreps(APIView):
    def get(self, request):
        players = Players()
        players.get_state_teams("Nevada")
        return Response("completed..")
