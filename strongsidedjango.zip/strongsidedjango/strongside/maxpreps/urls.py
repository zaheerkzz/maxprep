from django.urls import path
from .views import MaxPreps

urlpatterns = [
    path('maxprepPlayers/', MaxPreps.as_view())
]