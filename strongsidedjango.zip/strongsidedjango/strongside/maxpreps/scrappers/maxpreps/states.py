import requests
from bs4 import BeautifulSoup as Soup

satates_dict = {'Alabama': 'https://www.maxpreps.com/al/football/', 'Alaska': 'https://www.maxpreps.com/ak/football/', 'Arizona': 'https://www.maxpreps.com/az/football/', 'Arkansas': 'https://www.maxpreps.com/ar/football/', 'California': 'https://www.maxpreps.com/ca/football/', 'Colorado': 'https://www.maxpreps.com/co/football/', 'Connecticut': 'https://www.maxpreps.com/ct/football/', 'Delaware': 'https://www.maxpreps.com/de/football/', 'Florida': 'https://www.maxpreps.com/fl/football/', 'Georgia': 'https://www.maxpreps.com/ga/football/', 'Hawaii': 'https://www.maxpreps.com/hi/football/', 'Idaho': 'https://www.maxpreps.com/id/football/', 'Illinois': 'https://www.maxpreps.com/il/football/', 'Indiana': 'https://www.maxpreps.com/in/football/', 'Iowa': 'https://www.maxpreps.com/ia/football/', 'Kansas': 'https://www.maxpreps.com/ks/football/', 'Kentucky': 'https://www.maxpreps.com/ky/football/', 'Louisiana': 'https://www.maxpreps.com/la/football/', 'Maine': 'https://www.maxpreps.com/me/football/', 'Maryland': 'https://www.maxpreps.com/md/football/', 'Massachusetts': 'https://www.maxpreps.com/ma/football/', 'Michigan': 'https://www.maxpreps.com/mi/football/', 'Minnesota': 'https://www.maxpreps.com/mn/football/', 'Mississippi': 'https://www.maxpreps.com/ms/football/', 'Missouri': 'https://www.maxpreps.com/mo/football/', 'Montana': 'https://www.maxpreps.com/mt/football/',
                'Nebraska': 'https://www.maxpreps.com/ne/football/', 'Nevada': 'https://www.maxpreps.com/nv/football/', 'New Hampshire': 'https://www.maxpreps.com/nh/football/', 'New Jersey': 'https://www.maxpreps.com/nj/football/', 'New Mexico': 'https://www.maxpreps.com/nm/football/', 'New York': 'https://www.maxpreps.com/ny/football/', 'North Carolina': 'https://www.maxpreps.com/nc/football/', 'North Dakota': 'https://www.maxpreps.com/nd/football/', 'Ohio': 'https://www.maxpreps.com/oh/football/', 'Oklahoma': 'https://www.maxpreps.com/ok/football/', 'Oregon': 'https://www.maxpreps.com/or/football/', 'Pennsylvania': 'https://www.maxpreps.com/pa/football/', 'Prep Schools': 'https://www.maxpreps.com/ps/football/', 'Rhode Island': 'https://www.maxpreps.com/ri/football/', 'South Carolina': 'https://www.maxpreps.com/sc/football/', 'South Dakota': 'https://www.maxpreps.com/sd/football/', 'Tennessee': 'https://www.maxpreps.com/tn/football/', 'Texas': 'https://www.maxpreps.com/tx/football/', 'Utah': 'https://www.maxpreps.com/ut/football/', 'Vermont': 'https://www.maxpreps.com/vt/football/', 'Virginia': 'https://www.maxpreps.com/va/football/', 'Washington': 'https://www.maxpreps.com/wa/football/', 'Washington, DC': 'https://www.maxpreps.com/dc/football/', 'West Virginia': 'https://www.maxpreps.com/wv/football/', 'Wisconsin': 'https://www.maxpreps.com/wi/football/', 'Wyoming': 'https://www.maxpreps.com/wy/football/'}


class States:
    def get_states():
        headers = {
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36'
        }
        state_url = 'https://www.maxpreps.com/football/#states'
        response = requests.get(url=state_url, headers=headers)
        pageSoup = Soup(response.text, 'html.parser')
        states = pageSoup.findAll(
            'div', class_='StyledLinksCard__StyledLinksGrid-sc-1l6hysw-1 hEdUIf')[0]
        for state in states.findAll('a'):
            satates_dict[state.text] = state['href']

        print(satates_dict)

    def get_state_url(state_name):
        return satates_dict[state_name]


# state_name = 'new hampshire'
# get_state_url(state_name=state_name)
