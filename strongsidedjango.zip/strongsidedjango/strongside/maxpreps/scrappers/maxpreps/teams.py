import requests
from bs4 import BeautifulSoup as Soup
import re

class Teams:
    teamUrls = []

    def getTeams(self):
        teamsUrl = 'https://www.maxpreps.com/search/default.aspx?type=school&search=&state=&gendersport=boys,football'
        response = requests.get(url=teamsUrl, headers=settings.headers)
        teamSoup = Soup(response.text, 'html.parser')
        teams = teamSoup.find('ul', class_='results-list')
        for li in teams.findAll('li'):
            schoolLink = li.find('div', class_='school-link')
            if schoolLink is not None:
                schoolLink = schoolLink['href']
                self.teamUrls.append(schoolLink)
        
    def teamDetails(self):
        teamDict = {}
        # for team in self.teamUrls:
        team = 'https://www.maxpreps.com/ky/elkton/todd-county-central-rebels/'
        response = requests.get(url=team, headers=settings.headers)
        teamSoup = Soup(response.text, 'html.parser')
        topDiv = teamSoup.find('div', {'id': '__next'})
        teamTop = topDiv.find('div', class_='StyledSchoolTeamHeader-sc-16zo2nl-0')
        teamImage = teamTop.find('img')
        teamImage = teamImage['src'] if teamImage is not None else ""
        teamDict['team image'] = teamImage

        teamDetails = topDiv.find('div', class_='StyledCard-sc-1hrko28-0')
        schoolName = teamDetails.find('h1')
        schoolName = schoolName.text if schoolName is not None else ""
        teamDict['school Name'] = schoolName

        schoolInfo = teamDetails.find('dl')
        
        try:
            info = schoolInfo.findAll('dd')
            address = info[0].text if info[0] is not None else ""
            mascot = info[1].text if info[1] is not None else ""
            colors = info[2].text if info[2] is not None else ""
            schoolType = info[3].text if info[3] is not None else ""
            athelaticDirector = info[4].text if info[4] is not None else ""
            phone = info[5].text if info[5] is not None else "" 

            teamDict['address'] = address
            teamDict['mascot'] = mascot
            teamDict['colors'] = re.findall('.[^A-Z]*', colors)
            teamDict['school type'] = schoolType
            teamDict['athelatic director'] = athelaticDirector
            teamDict['phone'] = phone
        except IndexError:
            pass

        print(str(teamDict).replace("'", '"'))