from statistics import mode
from django.db import models

# Create your models here.


class States(models.Model):
    state_name = models.CharField(max_length=255)
    state_url = models.CharField(max_length=255)


class Teams(models.Model):
    team_image = models.CharField(max_length=255)
    school_name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    mascot = models.CharField(max_length=255)
    colors = models.CharField(max_length=255)
    school_type = models.CharField(max_length=255)
    athelatic_director = models.CharField(max_length=255)
    phone = models.CharField(max_length=255)


class Players(models.Model):
    image_url = models.CharField(max_length=255)
    player_name = models.CharField(max_length=255)
    school_name = models.CharField(max_length=255)
    jersy = models.CharField(max_length=255)
    position = models.CharField(max_length=255)
    player_attributes = models.JSONField(null=True, blank=True)
    explaination = models.TextField(null=True, blank=True)
    featured_statistics = models.JSONField(null=True, blank=True)
    statistics = models.JSONField(null=True, blank=True)
    state_id = models.ForeignKey(
        States, on_delete=models.PROTECT, null=True, blank=True, related_name='state')
    team_id = models.ForeignKey(
        Teams, on_delete=models.PROTECT, null=True, blank=True, related_name='team')
